from setuptools import setup

setup(name='my_acrobot',
      version='0.0.1',
      install_requires=['gym']
)