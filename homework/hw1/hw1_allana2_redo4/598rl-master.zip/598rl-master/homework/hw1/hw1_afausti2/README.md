HW 1 directory for Alex Faustino.
