print('yay')
