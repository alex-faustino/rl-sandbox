HW1 folder for Abdul Alkurdi
